// DOM elements
const errorMesgEl = document.querySelector(".error_message");
const expenseDesEl = document.querySelector("#expense_name");
const expenseAmountEl = document.querySelector("#expense_amount");
const expenseDateEl = document.querySelector("#date");
const expenseCategoryEl = document.querySelector("#category");

const budgetCardEl = document.querySelector("#budget_card");
const expensesCardEl = document.querySelector("#expenses_card");
const balanceCardEl = document.querySelector("#balance_card");
const tblRecordEl = document.querySelector(".tbl_data");

let itemList = [];
let itemId = 0;

document.addEventListener("DOMContentLoaded", () => {
  const btnExpenses = document.querySelector("#btn_expenses");

  // Load saved budget
  const storedBudget = localStorage.getItem("userBudget");
  if (storedBudget) {
    budgetCardEl.textContent = storedBudget;
  } else {
    budgetCardEl.textContent = "0";
  }

  // Load saved expenses
  const savedExpenses = JSON.parse(localStorage.getItem("userExpenses")) || [];
  itemList = savedExpenses;
  itemId = itemList.length;

  itemList.forEach(exp => renderExpense(exp));
  updateExpenses();

  // Add expense
  btnExpenses.addEventListener("click", (e) => {
    e.preventDefault();
    addExpense();
  });

  // Handle edit/delete
  tblRecordEl.addEventListener("click", handleTableClick);
});

function addExpense() {
  const description = expenseDesEl.value.trim();
  const amountValue = expenseAmountEl.value.trim();
  const dateValue = expenseDateEl.value;
  const categoryValue = expenseCategoryEl.value;
  const amount = parseInt(amountValue);

  if (!description || isNaN(amount) || amount <= 0 || !dateValue || !categoryValue) {
    showError("Please enter all valid expense details.");
    return;
  }

  const expense = {
    id: itemId++,
    title: description,
    amount: amount,
    date: dateValue,
    category: categoryValue
  };

  itemList.push(expense);
  localStorage.setItem("userExpenses", JSON.stringify(itemList));

  renderExpense(expense);
  updateExpenses();

  expenseDesEl.value = "";
  expenseAmountEl.value = "";
  expenseDateEl.value = "";
  expenseCategoryEl.value = "";
}

function renderExpense(expense) {
  const html = `<ul class="tbl_tr_content" data-id="${expense.id}">
    <li>${expense.id + 1}.</li>
    <li>${expense.title}</li>
    <li><span>$</span>${expense.amount}</li>
    <li>${expense.category}</li>
    <li>${expense.date}</li>
    <li>
      <button class="btn_edit">Edit</button>
      <button class="btn_delete">Delete</button>
    </li>
  </ul>`;
  tblRecordEl.insertAdjacentHTML("beforeend", html);
}

function handleTableClick(e) {
  const target = e.target;
  const row = target.closest(".tbl_tr_content");
  const id = parseInt(row.dataset.id);

  if (target.classList.contains("btn_edit")) {
    const toEdit = itemList.find(i => i.id === id);
    if (toEdit) {
      expenseDesEl.value = toEdit.title;
      expenseAmountEl.value = toEdit.amount;
      expenseDateEl.value = toEdit.date;
      expenseCategoryEl.value = toEdit.category;

      itemList = itemList.filter(i => i.id !== id);
      localStorage.setItem("userExpenses", JSON.stringify(itemList));
      row.remove();
      updateExpenses();
    }
  }

  if (target.classList.contains("btn_delete")) {
    itemList = itemList.filter(i => i.id !== id);
    localStorage.setItem("userExpenses", JSON.stringify(itemList));
    row.remove();
    updateExpenses();
  }
}

function updateExpenses() {
  const total = itemList.reduce((sum, i) => sum + i.amount, 0);
  expensesCardEl.textContent = total;

  const budget = parseInt(budgetCardEl.textContent);
  const balance = budget - total;
  balanceCardEl.textContent = balance;
}

function showError(msg) {
  errorMesgEl.textContent = msg;
  setTimeout(() => {
    errorMesgEl.textContent = "";
  }, 2500);
}