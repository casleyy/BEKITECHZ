Chart.defaults.borderColor = '#2a4c09';
Chart.defaults.color = '#2a4c09';

// Load data
const userExpenses = JSON.parse(localStorage.getItem("userExpenses")) || [];
const userBudget = parseInt(localStorage.getItem("userBudget")) || 0;

// ===== 1. Bar Chart: Average Expenses Per Category =====
const categorySums = {};
const categoryCounts = {};

userExpenses.forEach(expense => {
  const cat = expense.category;
  if (!categorySums[cat]) {
    categorySums[cat] = 0;
    categoryCounts[cat] = 0;
  }
  categorySums[cat] += expense.amount;
  categoryCounts[cat] += 1;
});

const barLabels = Object.keys(categorySums);
const barData = barLabels.map(cat => (categorySums[cat] / categoryCounts[cat]).toFixed(2));

const barCanvas = document.getElementById('bar-chart');
if (barCanvas) {
  new Chart(barCanvas, {
    type: 'bar',
    data: {
      labels: barLabels,
      datasets: [{
        data: barData,
        backgroundColor: "#2196f3"
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } }
    }
  });
}

// ===== 2. Line Chart: Budget vs Spending By Month =====
const monthlySpent = {};
userExpenses.forEach(expense => {
  const month = expense.date.slice(0, 7); // "YYYY-MM"
  if (!monthlySpent[month]) monthlySpent[month] = 0;
  monthlySpent[month] += expense.amount;
});

const months = Object.keys(monthlySpent).sort();
const spentValues = months.map(m => monthlySpent[m]);
const budgetValues = months.map(() => userBudget);

const lineCanvas = document.getElementById('line-chart');
if (lineCanvas) {
  new Chart(lineCanvas, {
    type: 'line',
    data: {
      labels: months,
      datasets: [
        {
          label: "Total Spent",
          data: spentValues,
          backgroundColor: "rgba(0, 173, 253, 0.6)",
          borderColor: "#2196f3",
          fill: true,
          tension: 0.1
        },
        {
          label: "Budget Limit",
          data: budgetValues,
          backgroundColor: "rgba(253, 202, 0, 0.6)",
          borderColor: "#fbc02d",
          fill: true,
          tension: 0.1
        }
      ]
    },
    options: {
      responsive: true,
      scales: { y: { beginAtZero: true } },
      plugins: { legend: { display: true } }
    }
  });
}

// ===== 3. Pie Chart: This Month's Expenses Per Category =====
const now = new Date();
const thisMonth = now.toISOString().slice(0, 7); // "YYYY-MM"
const monthlyExpenses = userExpenses.filter(e => e.date.startsWith(thisMonth));
const monthlyCategoryTotals = {};

monthlyExpenses.forEach(exp => {
  const cat = exp.category;
  if (!monthlyCategoryTotals[cat]) monthlyCategoryTotals[cat] = 0;
  monthlyCategoryTotals[cat] += exp.amount;
});

const pieLabels = Object.keys(monthlyCategoryTotals);
const pieData = Object.values(monthlyCategoryTotals);

const pieCanvas = document.getElementById('pie-chart');
if (pieCanvas) {
  new Chart(pieCanvas, {
    type: 'pie',
    data: {
      labels: pieLabels,
      datasets: [{
        data: pieData,
        borderColor: '#2a4c09',
        backgroundColor: ["#81a969", "#fbc02d", "#388e3c", "#d32f2f", "#cfe8ff"]
      }]
    },
    options: {
      plugins: {
        legend: { display: true }
      }
    }
  });
}

// ===== 4. Update the Text Breakdown Next to Pie Chart =====
const paragraphContainer = document.getElementById("paragraph-flex-container");
if (paragraphContainer) {
  paragraphContainer.innerHTML = "";
  const total = pieData.reduce((a, b) => a + b, 0);
  pieLabels.forEach((label, i) => {
    const amount = pieData[i];
    const percent = total ? ((amount / total) * 100).toFixed(1) : 0;
    const p = document.createElement("p");
    p.textContent = `${label}: P${amount} (${percent}% of Total)`;
    paragraphContainer.appendChild(p);
  });
}
