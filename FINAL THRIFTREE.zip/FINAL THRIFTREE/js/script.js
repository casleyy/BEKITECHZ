



// pie chart dashboard
"use strict";

document.addEventListener("DOMContentLoaded", () => {
  const pieData = [
    { label: "Food", value: 300, color: "#81a969" },
    { label: "Transport", value: 150, color: "#fbc02d" },
    { label: "Utilities", value: 200, color: "#388e3c" },
    { label: "Entertainment", value: 100, color: "#d32f2f" },
    { label: "Others", value: 250, color: "#cfe8ff" }
  ];

  const svg = document.querySelector(".custom-pie-chart");
  const tooltip = document.getElementById("tooltip");
  if (!svg) return;

  const total = pieData.reduce((sum, item) => sum + item.value, 0);
  let cumulativePercent = 0;

  pieData.forEach(item => {
    const startPercent = cumulativePercent;
    const slicePercent = item.value / total;
    cumulativePercent += slicePercent;

    const [startX, startY] = getCoordinatesForPercent(startPercent);
    const [endX, endY] = getCoordinatesForPercent(cumulativePercent);
    const largeArcFlag = slicePercent > 0.5 ? 1 : 0;

    const pathData = [
      `M 20 20`,
      `L ${startX} ${startY}`,
      `A 20 20 0 ${largeArcFlag} 1 ${endX} ${endY}`,
      `Z`
    ].join(" ");

    const group = document.createElementNS("http://www.w3.org/2000/svg", "g");
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");

    path.setAttribute("d", pathData);
    path.setAttribute("fill", item.color);
    path.style.transition = "transform 0.3s ease, fill 0.3s ease";

    // Tooltip + hover movement
    group.addEventListener("mouseover", (e) => {
      path.style.fill = "#8B0000"; // Dark red on hover

      const radians = 2 * Math.PI * (startPercent + slicePercent / 2);
      const dx = Math.cos(radians) * 2.5;
      const dy = Math.sin(radians) * 2.5;
      group.setAttribute("transform", `translate(${dx}, ${dy})`);

      tooltip.style.display = "block";
      tooltip.innerText = `${item.label}: $${item.value} (${(slicePercent * 100).toFixed(1)}%)`;
    });

    group.addEventListener("mousemove", (e) => {
      tooltip.style.left = e.pageX + 10 + "px";
      tooltip.style.top = e.pageY + 10 + "px";
    });

    group.addEventListener("mouseout", () => {
      path.style.fill = item.color;
      group.removeAttribute("transform");
      tooltip.style.display = "none";
    });

    group.appendChild(path);
    svg.appendChild(group);
  });

  function getCoordinatesForPercent(percent) {
    const radius = 20;
    const x = Math.cos(2 * Math.PI * percent) * radius + 20;
    const y = Math.sin(2 * Math.PI * percent) * radius + 20;
    return [x, y];
  }
});



// Select DOM elements
const errorMesgEl = document.querySelector(".error_message");
const budgetInputEl = document.querySelector(".budget_input");
const expenseDesEl = document.querySelector(".expensess_input");
const expenseAmountEl = document.querySelector(".expensess_amount");
const tblRecordEl = document.querySelector(".tbl_data");

// Cards
const budgetCardEl = document.querySelector("#budget_card");
const expensesCardEl = document.querySelector("#expenses_card");
const balanceCardEl = document.querySelector("#balance_card");

// Variables
let itemList = [];
let itemId = 0;

// Button events
function btnEvents() {
  const btnBudgetCal = document.querySelector('#btn_budget');
  const btnExpensesCal = document.querySelector('#btn_expenses');

  btnBudgetCal.addEventListener("click", (e) => {
    e.preventDefault();
    budgetFun();
  });

  btnExpensesCal.addEventListener("click", (e) => {
    e.preventDefault();
    expensesFun();
  });

  // Event delegation for edit and delete buttons
  tblRecordEl.addEventListener("click", handleTableClick);
}

// Call on page load
document.addEventListener("DOMContentLoaded", btnEvents);

// Budget function
function budgetFun() {
  const budgetValue = budgetInputEl.value;

  if (budgetValue === "" || budgetValue < 0) {
    errorMessage("Please Enter Your Budget or More Than 0");
  } else {
    budgetCardEl.textContent = budgetValue;
    budgetInputEl.value = "";
    showBalance();
  }
}

// Expenses function
function expensesFun() {
  const expensesDescValue = expenseDesEl.value.trim();
  const expensesAmountValue = expenseAmountEl.value.trim();

  if (
    expensesDescValue === "" ||
    expensesAmountValue === "" ||
    isNaN(parseInt(expensesAmountValue)) ||
    parseInt(expensesAmountValue) < 0
  ) {
    errorMessage("Please enter a valid expense description and amount!");
    return;
  }

  const amount = parseInt(expensesAmountValue);

  const expenses = {
    id: itemId,
    title: expensesDescValue,
    amount: amount,
  };

  itemId++;
  itemList.push(expenses);
  addExpenses(expenses);
  showBalance();

  expenseDesEl.value = "";
  expenseAmountEl.value = "";
}

// Add expense row to table
function addExpenses(expense) {
  const html = `<ul class="tbl_tr_content" data-id="${expense.id}">
      <li>${expense.id+1}.</li>
      <li>${expense.title}</li>
      <li><span>$</span>${expense.amount}</li>
      <li>
        <button type="button" class="btn_edit">Edit</button>
        <button type="button" class="btn_delete">Delete</button>
      </li>
    </ul>`;

  tblRecordEl.insertAdjacentHTML("beforeend", html);
}

// Handle edit/delete via event delegation
function handleTableClick(e) {
  const target = e.target;
  const row = target.closest(".tbl_tr_content");
  const id = parseInt(row.dataset.id);

  if (target.classList.contains("btn_edit")) {
    const expenseToEdit = itemList.find(item => item.id === id);
    if (expenseToEdit) {
      expenseDesEl.value = expenseToEdit.title;
      expenseAmountEl.value = expenseToEdit.amount;

      // Remove from DOM and list
      itemList = itemList.filter(item => item.id !== id);
      row.remove();
      showBalance();
    }
  }

  if (target.classList.contains("btn_delete")) {
    // Remove from DOM and list
    itemList = itemList.filter(item => item.id !== id);
    row.remove();
    showBalance();
  }
}

// Show balance function
function showBalance() {
  const expenses = totalExpenses();
  const budgetValue = parseInt(budgetCardEl.textContent.replace(/[^0-9]/g, ""));
  const total = budgetValue - expenses;
  balanceCardEl.textContent = total;
}

// Calculate total expenses
function totalExpenses() {
  let total = 0;

  if (itemList.length > 0) {
    total = itemList.reduce((acc, curr) => acc + curr.amount, 0);
  }

  expensesCardEl.textContent = total;
  return total;
}

// Show error message
function errorMessage(message) {
  errorMesgEl.innerHTML = `<p>${message}</p>`;
  errorMesgEl.classList.add("error");

  setTimeout(() => {
    errorMesgEl.classList.remove("error");
  }, 2500);
}
