Chart.defaults.borderColor = '#2a4c09';
Chart.defaults.color = '#2a4c09';

function checkSubscriptionPlan() {
    const userPlan = localStorage.getItem("plan");
    const analyticsContent = document.getElementById("analytics-content");
    const subscriptionModal = document.getElementById("subscription-modal");

    if (userPlan === "boosted") {
        if (analyticsContent) {
            analyticsContent.style.display = "grid"; 
        }
        if (subscriptionModal) {
            subscriptionModal.style.display = "none";
        }
        loadAnalyticsData();
    } else {
        //free pan, shows overlay
        if (analyticsContent) {
            analyticsContent.style.display = "grid"; 
            

            //clear content
            const barCanvas = document.getElementById('bar-chart');
            const lineCanvas = document.getElementById('line-chart');
            const pieCanvas = document.getElementById('pie-chart');
            const paragraphContainer = document.getElementById("paragraph-flex-container");

            if (barCanvas) barCanvas.innerHTML = '';
            if (lineCanvas) lineCanvas.innerHTML = '';
            if (pieCanvas) pieCanvas.innerHTML = '';
            if (paragraphContainer) paragraphContainer.innerHTML = '';



        }
        if (subscriptionModal) {
            subscriptionModal.style.display = "flex";
        }
    }
}

// redirectign
function redirectToDashboard() {
    window.location.href = "dashboard.html"; 
}

function redirectToPlans() {
    window.location.href = "subscriptions.html"; 
}

function loadAnalyticsData() {
    //loading data
    const userExpenses = JSON.parse(localStorage.getItem("userExpenses")) || [];
    const userBudget = parseInt(localStorage.getItem("userBudget")) || 0;

    //bar
    const categorySums = {};
    const categoryCounts = {};

    userExpenses.forEach(expense => {
        const cat = expense.category;
        if (!categorySums[cat]) {
            categorySums[cat] = 0;
            categoryCounts[cat] = 0;
        }
        categorySums[cat] += expense.amount;
        categoryCounts[cat] += 1;
    });

    const barLabels = Object.keys(categorySums);
    const barData = barLabels.map(cat => (categorySums[cat] / categoryCounts[cat]).toFixed(2));

    const barCanvas = document.getElementById('bar-chart');
    if (barCanvas) {
        if (Chart.getChart(barCanvas)) Chart.getChart(barCanvas).destroy();
        new Chart(barCanvas, {
            type: 'bar',
            data: {
                labels: barLabels,
                datasets: [{
                    data: barData,
                    backgroundColor: "#2196f3"
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true } }
            }
        });
    }

    //lie chart
    const monthlySpent = {};
    userExpenses.forEach(expense => {
        const month = expense.date.slice(0, 7); // "YYYY-MM"
        if (!monthlySpent[month]) monthlySpent[month] = 0;
        monthlySpent[month] += expense.amount;
    });

    const months = Object.keys(monthlySpent).sort();
    const spentValues = months.map(m => monthlySpent[m]);
    const budgetValues = months.map(() => userBudget);

    const lineCanvas = document.getElementById('line-chart');
    if (lineCanvas) {
        
        if (Chart.getChart(lineCanvas)) Chart.getChart(lineCanvas).destroy();
        new Chart(lineCanvas, {
            type: 'line',
            data: {
                labels: months,
                datasets: [
                    {
                        label: "Total Spent",
                        data: spentValues,
                        backgroundColor: "rgba(0, 173, 253, 0.6)",
                        borderColor: "#2196f3",
                        fill: true,
                        tension: 0.1
                    },
                    {
                        label: "Budget Limit",
                        data: budgetValues,
                        backgroundColor: "rgba(253, 202, 0, 0.6)",
                        borderColor: "#fbc02d",
                        fill: true,
                        tension: 0.1
                    }
                ]
            },
            options: {
                responsive: true,
                scales: { y: { beginAtZero: true } },
                plugins: { legend: { display: true } }
            }
        });
    }

    // pie
    const now = new Date();
    const thisMonth = now.toISOString().slice(0, 7); 
    const monthlyExpenses = userExpenses.filter(e => e.date.startsWith(thisMonth));
    const monthlyCategoryTotals = {};

    monthlyExpenses.forEach(exp => {
        const cat = exp.category;
        if (!monthlyCategoryTotals[cat]) monthlyCategoryTotals[cat] = 0;
        monthlyCategoryTotals[cat] += exp.amount;
    });

    const pieLabels = Object.keys(monthlyCategoryTotals);
    const pieData = Object.values(monthlyCategoryTotals);

    const pieCanvas = document.getElementById('pie-chart');
    if (pieCanvas) {


        if (Chart.getChart(pieCanvas)) Chart.getChart(pieCanvas).destroy();
        new Chart(pieCanvas, {
            type: 'pie',
            data: {
                labels: pieLabels,
                datasets: [{
                    data: pieData,
                    borderColor: '#2a4c09',
                    backgroundColor: ["#81a969", "#fbc02d", "#388e3c", "#d32f2f", "#cfe8ff"]
                }]
            },
            options: {
                plugins: {
                    legend: { display: true }
                }
            }
        });
    }

    //text updat
    const paragraphContainer = document.getElementById("paragraph-flex-container");
    if (paragraphContainer) {
        paragraphContainer.innerHTML = "";
        const total = pieData.reduce((a, b) => a + b, 0);
        pieLabels.forEach((label, i) => {
            const amount = pieData[i];
            const percent = total ? ((amount / total) * 100).toFixed(1) : 0;
            const p = document.createElement("p");
            p.textContent = `${label}: P${amount} (${percent}% of Total)`;
            paragraphContainer.appendChild(p);
        });
    }
}

//check kapag booster
document.addEventListener("DOMContentLoaded", checkSubscriptionPlan);