// DOM elements
const errorMesgEl = document.querySelector(".error_message");
const expenseDesEl = document.querySelector("#expense_name");
const expenseAmountEl = document.querySelector("#expense_amount");
const expenseDateEl = document.querySelector("#date");
const expenseCategoryEl = document.querySelector("#category");
const warningEl = document.querySelector("#budgetWarning");
const overBudgetWarning = document.querySelector("#overBudgetWarning");



const budgetCardEl = document.querySelector("#budget_card");
const expensesCardEl = document.querySelector("#expenses_card");
const balanceCardEl = document.querySelector("#balance_card");
const tblRecordEl = document.querySelector(".tbl_data");

let itemList = [];
let itemId = 0;

document.addEventListener("DOMContentLoaded", () => {
  const btnExpenses = document.querySelector("#btn_expenses");

  // saved budget
  const storedBudget = localStorage.getItem("userBudget");
  if (storedBudget) {
    budgetCardEl.textContent = storedBudget;
  } else {
    budgetCardEl.textContent = "0";
  }

  //expenses
  const savedExpenses = JSON.parse(localStorage.getItem("userExpenses")) || [];
  itemList = savedExpenses;
  itemId = itemList.length;

  itemList.forEach(exp => renderExpense(exp));
  updateExpenses();

  btnExpenses.addEventListener("click", (e) => {
    e.preventDefault();
    addExpense();
  });

  tblRecordEl.addEventListener("click", handleTableClick);
});

function addExpense() {
  const description = expenseDesEl.value.trim();
  const amountValue = expenseAmountEl.value.trim();
  const dateValue = expenseDateEl.value;
  const categoryValue = expenseCategoryEl.value;
  const amount = parseInt(amountValue);

  if (!description || isNaN(amount) || amount <= 0 || !dateValue || !categoryValue) {
    showError("Please enter all valid expense details.");
    return;
  }

  const expense = {
    id: itemId++,
    title: description,
    amount: amount,
    date: dateValue,
    category: categoryValue
  };

  itemList.push(expense);
  localStorage.setItem("userExpenses", JSON.stringify(itemList));

  renderExpense(expense);
  updateExpenses();

  expenseDesEl.value = "";
  expenseAmountEl.value = "";
  expenseDateEl.value = "";
  expenseCategoryEl.value = "";
}

function renderExpense(expense) {
  const html = `<ul class="tbl_tr_content" data-id="${expense.id}">
    <li>${expense.id + 1}.</li>
    <li>${expense.title}</li>
    <li><span>₱</span>${expense.amount}</li>
    <li>${expense.category}</li>
    <li>${expense.date}</li>
    <li>
      <button class="btn_edit">Edit</button>
      <button class="btn_delete">Delete</button>
    </li>
  </ul>`;
  tblRecordEl.insertAdjacentHTML("beforeend", html);
}

function handleTableClick(e) {
  const target = e.target;
  const row = target.closest(".tbl_tr_content");
  const id = parseInt(row.dataset.id);

  if (target.classList.contains("btn_edit")) {
    const toEdit = itemList.find(i => i.id === id);
    if (toEdit) {
      expenseDesEl.value = toEdit.title;
      expenseAmountEl.value = toEdit.amount;
      expenseDateEl.value = toEdit.date;
      expenseCategoryEl.value = toEdit.category;

      itemList = itemList.filter(i => i.id !== id);
      localStorage.setItem("userExpenses", JSON.stringify(itemList));
      row.remove();
      updateExpenses();
    }
  }

  if (target.classList.contains("btn_delete")) {
    itemList = itemList.filter(i => i.id !== id);
    localStorage.setItem("userExpenses", JSON.stringify(itemList));
    row.remove();
    updateExpenses();
  }
}


function updateExpenses() {
  const total = itemList.reduce((sum, i) => sum + i.amount, 0);
  expensesCardEl.textContent = total;

  const budget = parseInt(budgetCardEl.textContent);
  const balance = budget - total;
  balanceCardEl.textContent = balance;

//warninfs
  warningEl.classList.add("hidden");
  overBudgetWarning.classList.add("hidden");

  if (budget > 0) {
    const percentageLeft = (balance / budget) * 100;

    if (percentageLeft <= 20 && percentageLeft > 0) {
      warningEl.textContent = "Warning! You are nearing your budget limit!";
      warningEl.classList.remove("hidden");
    }

    if (balance < 0) {
      overBudgetWarning.textContent = "You have exceeded your budget limit!";
      overBudgetWarning.classList.remove("hidden");
    }
  }
}





//currently doing warning for 80 PERCENT NOT  WORKING CURRENTLY

function showError(msg) {
  errorMesgEl.textContent = msg;
  errorMesgEl.style.display = "block";  
  errorMesgEl.style.color = "white";

  setTimeout(() => {
    errorMesgEl.textContent = "";
    errorMesgEl.style.display = "none"; 
  }, 2500);
}


warningEl.addEventListener("click", () => {
  warningEl.classList.add("hidden");
});

overBudgetWarning.addEventListener("click", () => {
  overBudgetWarning.classList.add("hidden");
});
