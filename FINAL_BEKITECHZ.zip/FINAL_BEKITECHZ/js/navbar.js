function openNav() {
    document.getElementById("site-sidenav").style.width = "275px";
}

function closeNav() {
    document.getElementById("site-sidenav").style.width = "0";
}